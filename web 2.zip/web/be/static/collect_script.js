document.querySelector('.input-button').addEventListener('click', function() {
    window.location.href = 'hw(1).html'; 
  });