import pymongo
from pymongo.errors import PyMongoError
from model import db_conn
from model import error
import time

class Trans(db_conn.DBConn):

    def __init__(self):
        db_conn.DBConn.__init__(self)

    def trans_in(self, data: dict) -> (int, str, int):
        try:
            if data is None:
                return 200, "ok", -1
            else:
                data['timestamp'] = time.time()
                self.db['trans_in'].insert_one(data)

            score = pred_score(data)
            if score < 0:
                return 200, "ok", -1
            else:
                self.db['score'].insert_one({'score': score, 'timestamp': time.time()})

        except PyMongoError as e:
            return 528, "{}".format(str(e)), -1
        except BaseException as e:
            return 530, "{}".format(str(e)), -1
        return 200, "ok", score
    
    def get_result(self) -> (int, str, int):
        try:
            find_result = self.db['score'].find_one(sort=[('timestamp', pymongo.DESCENDING)])
            score = find_result['score']
            if score is None:
                return 200, "ok", -1
            else:
                return 200, "ok", score
            
        except PyMongoError as e:
            return 528, "{}".format(str(e)), -1
        except BaseException as e:
            return 530, "{}".format(str(e)), -1
        return 200, "ok", score
