from flask import request
from flask import Blueprint
from flask import jsonify
from be.model.trans import Trans

bp_trans = Blueprint("trans", __name__, url_prefix="/trans")


@bp_trans.route("/trans_in", methods=["POST"])
def trans_in():
    data: dict = request.json
    t = Trans()
    code, message, score = t.trans_in(data)
    return jsonify({"message": message, "score": score}), code

@bp_trans.route("/get_result", methods=["POST"])
def get_result():
    t = Trans()
    code, message, score = t.get_result()
    return jsonify({"message": message, "score": score}), code